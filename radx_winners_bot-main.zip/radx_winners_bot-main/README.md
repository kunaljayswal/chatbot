# Paired Programming Challenge 2 Repository

Welcome to the Paired Programming Challenge 2 repository! This challenge involves building an AI agent that codes at an amateur level. Participants work with TaskMaster and Junior Bot to explore and analyze a dataset through collaborative pair programming.
